# Web Page Categorization using Machine Learning
I leveraged machine learning for web page categorization using the YektANet dataset. The model effectively predicts webpage categories,
achieving a 97% accuracy on test data.
